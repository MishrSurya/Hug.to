var formget = { "delay": "0" };
        var formget_box_visible = !1;
        var par_height = '';
        var par_netWidth = '';
        var par_netHeight = '';
        var tab_stat = '';
        var xmlhttp;
        var isMobile = !1;
        var heightBackup = '';
        var format = '';
        var secureUrl = 'https://d1izqpt1s10trr.cloudfront.net/main/css/';
        if (window.innerWidth <= 600) { isMobile = !0 }
        
        function img_loader(bgColor) {
            if (document.getElementById("fg-loader"))
                document.getElementById("fg-loader").remove();
            document.getElementById("brand_logo").insertAdjacentHTML('beforebegin', "<div id='fg-loader' class='fg_preloader'><div class='preloader-container'><span class='animated-preloader' style='background:#" + bgColor + "'></span></div></div>")
        }
        
        function getCookie(cname) {
            var name = cname + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') { c = c.substring(1) }
                if (c.indexOf(name) == 0) { return c.substring(name.length, c.length) }
            }
            return ""
        }
        
        function frameload() {
            if (tab_stat == 1) {
                var c = document.getElementById("formget_box");
                c.style.visibility = "visible"
            }
            if (document.getElementById("fg-loader") != null) { document.getElementById("fg-loader").style.display = "none" }
        }
        
        function formget_slider_tab_center() {
          var iframepopup = document.getElementById('popup-checkout-page');
          iframepopup.src = "";
            var c = document.getElementById("formget_box");
            var modal_obj = document.getElementById("center_modal");
            c.className = "modal-dialog"
            modal_obj.classList.remove("modal");
            c.style.display = "none"
        }
        
        var visible_height = '';
        
        function PopupCenter() {	          
            var c = document.getElementById("formget_box");
            var ifcAttr = c.getAttribute('ifc');
            if (ifcAttr == null) {
                c.setAttribute("ifc", !0);
                var makediv = document.getElementById("brand_logo");
                var makeIframe = "<iframe id='popup-checkout-page' class='popup-iframe' onload='frameload()' height='100%' allowTransparency='true' frameborder='0' scrolling='yes' width='100%' style='border:none' src='' sandbox='allow-forms allow-modals allow-popups allow-same-origin allow-scripts allow-top-navigation allow-top-navigation-by-user-activation'>Your Contact </iframe>";
                makediv.insertAdjacentHTML('beforebegin', makeIframe);        
            }
        }
        
        function init(par_getHeight, par_netWidth) {          
             setTimeout(function() { animate_formget(par_getHeight, par_netWidth) })
            if (/iPhone|iPod|iPad/i.test(navigator.userAgent)) {
                var wrapperId = "popup-wrapper_center";
                document.getElementById(wrapperId).style["webkit" + 'OverflowScrolling'] = "touch";
                document.getElementById(wrapperId).style.overflowY = "scroll"
            }
        }
        
        function animate_formget(par_getHeight, par_netWidth) {          
            var c = document.getElementById("formget_box");
            var b = document.getElementById("popup-header_center");
            var wrapper_r = document.getElementById("popup-wrapper_center");
            var inc_width = Number(par_netWidth)+ 50;
            var l_r_par_height = 0;
          if (window.innerHeight < parseInt(par_height)) {
            l_r_par_height = 80;
            par_getHeight = 10;
            format = '%'
          } else {
            l_r_par_height = parseInt(par_height);
            format = 'px'
          }

          if (window.innerWidth > 400) { c.style.width = (inc_width + 10) + 'px' } else {
            c.style.width = '90%';
            c.style.right = 'auto'
          }
          if (window.innerHeight < parseInt(par_height)) {
            if ((80 / 100) * window.innerHeight >= 650)
              par_height = par_getHeight = 650;
            else par_height = par_getHeight = (80 / 100) * window.innerHeight
          } else { if (par_height >= 650) { par_height = par_getHeight = 650 } else { par_getHeight = par_height } }
        //        c.style.height = par_getHeight + 'px';
          c.style.height = '500px';
          if (tab_stat == 0 || tab_stat == '') {
            c.style.visibility = "visible";
            c.style.bottom = "-" + (par_getHeight - 37) + 'px';
            c.setAttribute('class', 'formget-animated formget-bounce-in-up')
          } else {
            c.style.bottom = "0px";
            c.setAttribute('class', 'modal-dialog');
            setTimeout(function() { 480 < window.innerWidth }, 500);
            formget_box_visible = !0
          }
          PopupCenter();
          c.setAttribute('class', 'modal-dialog')
            
        }
        
          window.addEventListener("message", function (e) { 
   
            if (!['dynamicHeight', 'redirectUrl'].includes(e.data.type)) return;

            if(e.data.type == 'redirectUrl') {
              window.open(e.data.url, '_parent');
            }else if(e.data.type == 'dynamicHeight') {
              var this_frame = document.getElementById("formget_box");
              if (this_frame) {
                this_frame.height = Number(e.data.height) + "px";
                this_frame.style.height = Number(e.data.height) + "px";
              }
            }
          })
        
        function initializeOption(params) {
          par_height = params.height;
          par_netWidth = params.width;
          heightBackup = par_height;
          
          var body = document.getElementsByTagName('body')[0];
          var modal_wrap = document.createElement('div');
          modal_wrap.setAttribute('class', 'modal popup-checkout-modal');
          modal_wrap.setAttribute('id', 'center_modal');
          var slide_div = document.createElement('div');
          slide_div.setAttribute('id', 'formget_box');
          slide_div.setAttribute('data-class', 'fg_slide_center');
          window_height = window.innerHeight;
          par_netHeight = (window_height - par_height) / 2;
          var slide_div_center = document.createElement('div');
          slide_div_center.setAttribute('id', 'formget_box');
          slide_div_center.setAttribute('data-class', 'fg_slide_center');
          slide_div_center.setAttribute('style', 'overflow:hidden;');
          slide_div_center.setAttribute('style', 'padding-bottom: 35px;');
          window_height = window.innerHeight;
          
            slide_div_center.innerHTML = "<div id='popup-header_center' class='' style='background-color: rgb(23, 184, 111);'> <span ontouchstart='formget_slider_tab_center();' onclick='formget_slider_tab_center();' class='form-slide-close'></span></div><div id='popup-wrapper_center' class='popup-wrapper_bottom' style='position: absolute;width: 100%;'><span id='brand_logo'></span></div></div>";
            modal_wrap.appendChild(slide_div_center);
            body.appendChild(modal_wrap);
            par_height = Math.round((60 / 100) * window.innerHeight);
            init(par_height, par_netWidth)
          
        }
        
        function loadContent() {
          var head = document.getElementsByTagName('head')[0];
          var link = document.createElement('link');
          link.setAttribute("rel", "stylesheet");
          /* link.setAttribute("href", 'popup-checkout-style.css')*/
          link.setAttribute("href", secureUrl + 'popup-checkout-style.css')
          link.setAttribute("type", "text/css");
          head.appendChild(link)
        }
        
        function buildHtml() {}
        
        function loadajax(url, fid, asyn, func) {
            if (window.XMLHttpRequest) { xmlhttp = new XMLHttpRequest() } else { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP") }
            xmlhttp.onreadystatechange = func;
            xmlhttp.open("POST", url, asyn);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send("fid=" + fid)
        }
        
        function callOnResize() {
                heightBackup = document.getElementById('formget_box').style.height;
                var box_inner = document.getElementById('formget_box').clientHeight;
                var left_rigth_header = document.getElementById('popup-header_center');
                var par_height = Math.round((60 / 100) * window.innerHeight);
            
                switch (window.innerHeight <= heightBackup) {
                    case true:
                        if ((80 / 100) * window.innerHeight >= 650)
                            document.getElementById('formget_box').style.height = '650px';
                        else document.getElementById('formget_box').style.height = par_height + 'px';
                        break;
                    case false:
                        document.getElementById('formget_box').style.height = heightBackup + 'px';
                        document.getElementById('formget_box').style.top = ((window.innerHeight - par_height) / 2) + 'px';
                        break
                }
                box_inner = document.getElementById('formget_box').clientHeight;
                var height_diff = 0;
                var tab_height = left_rigth_header.clientHeight;
                tab_height = parseInt(tab_height)
        }
        
        function open_center_popup(checkouturl) {  
          var iframepopup = document.getElementById('popup-checkout-page');
          iframepopup.src = checkouturl;
            var c = document.getElementById("formget_box");
            var modal_obj = document.getElementById("center_modal");
            modal_obj.setAttribute("class", "modal popup-checkout-modal");
            modal_obj.style.display = "block";
            c.style.display = "block";
            var newsA = document.getElementById('popup-wrapper_center');
            var myDiv = newsA.getElementsByClassName('popup-iframe')[0];
            myDiv.setAttribute('style', 'width:""');
        }

        var options = { 'height': '907', 'width': '450'};

        if (document.readyState !== 'loading') {
          try {
            initializeOption(options);
            loadContent();
            buildHtml();
          } catch (e) { }
        } else {
          document.addEventListener("DOMContentLoaded", function(){
            //dom is fully loaded, but maybe waiting on images & css files
            try {
              initializeOption(options);
              loadContent();
              buildHtml();
            } catch (e) { }
          });
        }
        